"""
clip_engine/speaker_analysis.py
Speaker change / interruption detection (pyannote GPU optional, transcript fallback).
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("clip_engine.speaker_analysis")

_PYANNOTE_PIPELINE = None


def pyannote_available() -> bool:
    try:
        import pyannote.audio  # noqa: F401

        return True
    except ImportError:
        return False


def cuda_available() -> bool:
    try:
        import torch

        return bool(torch.cuda.is_available())
    except ImportError:
        return False


def get_speaker_device() -> str:
    return "cuda" if cuda_available() else "cpu"


def _load_pyannote_pipeline():
    """Lazy-load diarization pipeline (requires HF token for some models)."""
    global _PYANNOTE_PIPELINE
    if _PYANNOTE_PIPELINE is not None:
        return _PYANNOTE_PIPELINE
    try:
        from pyannote.audio import Pipeline
        import torch

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        pipeline = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1")
        pipeline.to(device)
        _PYANNOTE_PIPELINE = pipeline
        logger.info("[GPU] PyAnnote using CUDA: %s", device.type == "cuda")
        return pipeline
    except Exception as exc:
        logger.warning("PyAnnote diarization unavailable: %s", exc)
        return None


def diarize_audio_file(audio_path: str) -> list[dict]:
    """
    Run speaker diarization on audio file.
    Returns [{start, end, speaker}, ...]
    """
    pipeline = _load_pyannote_pipeline()
    if pipeline is None:
        return []
    try:
        diar = pipeline(audio_path)
        turns = []
        for turn, _, speaker in diar.itertracks(yield_label=True):
            turns.append(
                {
                    "start": float(turn.start),
                    "end": float(turn.end),
                    "speaker": str(speaker),
                }
            )
        return turns
    except Exception as exc:
        logger.warning("Diarization failed: %s", exc)
        return []


def boost_candidates_from_transcript_speakers(
    candidates: list[dict],
    segments: list[dict],
) -> list[dict]:
    """Boost scores where transcript shows speaker alternation / interruptions."""
    from clip_engine.speaker_signals import apply_speaker_signals_to_clips

    if not candidates or not segments:
        return candidates
    boosted = apply_speaker_signals_to_clips(candidates, segments, enabled=True)
    for c in boosted:
        alt = int(c.get("speaker_alternation_score", 0) or 0)
        intr = int(c.get("interruption_score", 0) or 0)
        if alt >= 55 or intr >= 50:
            c["composite_score"] = min(90, int(c.get("composite_score", 50)) + 8)
            c.setdefault("warnings", []).append("speaker_moment_boost")
    return boosted


def boost_candidates_from_diarization(
    candidates: list[dict],
    turns: list[dict],
    *,
    min_score_boost: int = 10,
) -> list[dict]:
    """Boost candidates overlapping speaker-change boundaries."""
    if not turns or not candidates:
        return candidates
    change_times = []
    last_sp = None
    for t in sorted(turns, key=lambda x: x["start"]):
        sp = t.get("speaker")
        if last_sp is not None and sp != last_sp:
            change_times.append(float(t["start"]))
        last_sp = sp

    for c in candidates:
        t0 = float(c.get("start_seconds", 0))
        t1 = float(c.get("end_seconds", t0))
        for ct in change_times:
            if t0 <= ct <= t1:
                c["composite_score"] = min(92, int(c.get("composite_score", 50)) + min_score_boost)
                c["speaker_diarization_boost"] = True
                break
    return candidates


def speaker_pipeline_status() -> dict[str, Any]:
    return {
        "pyannote_available": pyannote_available(),
        "cuda_available": cuda_available(),
        "device": get_speaker_device(),
        "pipeline_loaded": _PYANNOTE_PIPELINE is not None,
    }
